// Different available money transfer steps.
//
model.team_MONEY_TRANSFER_STEPS = [1000,2500,5000,10000,25000,50000];
