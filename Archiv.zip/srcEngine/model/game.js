Class("cwt.Game",{

	initialize: function(){
		this.players = cwt.List.generateList(MAX_PLAYER,cwt.Player);
		this.map = null;
	}
})

Class("cwt.Map",{

	STATIC:{

		tileDistance: function( t1, t2 ){
			
		}
	},

	initialize: function(){
		this.data = cwt.List.generateMatrix(MAX_WIDTH,MAX_HEIGHT);
		this.height = 0;
		this.width = 0;
	}
})