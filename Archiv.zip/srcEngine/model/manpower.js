// Man power data array that holds the amount times that units can be builded.
//
model.manpower_data = util.list( MAX_PLAYER, 999999 );
