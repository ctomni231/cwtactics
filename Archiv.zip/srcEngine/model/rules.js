// Holds all game rules.
//
model.rule_global = [];

// Holds all map rules.
//
model.rule_map = util.list( 20, null );
