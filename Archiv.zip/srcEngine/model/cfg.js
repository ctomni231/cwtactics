// Holds the configuration data of the actual game round.
//
model.cfg_configuration = {};