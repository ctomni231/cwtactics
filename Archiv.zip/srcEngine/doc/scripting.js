/*


### Difference to the event API

The scripting API is designed to change incoming data. Unlike the event API, every rule
in the rule list works with the result of the previous rule. It's more like a pipe. A value
will be thrown in this pipe and every rule modifies it.

*/
