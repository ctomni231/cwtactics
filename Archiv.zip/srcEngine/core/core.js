// Model namespace. Holds the complete game model.
//
var model = {};

// Controller namespace. Holds different functions that aren't connected directly to the model.
//
var controller = {};

// Utility namespace.
//
var util = {};

(function(k){function c(b,a){var e,g,d;2>arguments.length&&(a=b,b=null);e=a.Extends||null;delete a.Extends;g=a.Implements||null;delete a.Implements;d=a.initialize||null;delete a.initialize;d||(d=e?function(){e.apply(this,arguments)}:function(){});b&&l(d,b);c.inherit(d,e);c.implement(d,g);b&&m(d,b);c.extend(d,a,!0);null!=b&&c.namespace(b,d);return d}function n(b,a){b.toString=function(){return a}}function l(b,a){b.toString=function(){return a}}function m(b,a){b.prototype.toString=function(){return a}}
c.augment=function(b,a,e){var c,d,f;for(c in a)a.hasOwnProperty(c)&&(d=b.hasOwnProperty(c),e||!d)&&(d=b[c]=a[c],"function"===typeof d&&(f=(f=a.toString===Object.prototype.toString)?b.constructor:a.constructor,n(d,f+"::"+c)))};c.extend=function(b,a,e){a.STATIC&&(b.Super&&c.augment(b,b.Super._STATIC_,!0),c.augment(b,a.STATIC,!0),b._STATIC_=a.STATIC,delete a.STATIC);c.augment(b.prototype,a,e)};c.inherit=function(b,a){if(a){var e=function(){};e.prototype=a.prototype;b.prototype=new e;b.prototype.constructor=
b;b.Super=a;c.extend(b,a,!1)}};c.implement=function(b,a){if(a){var e;"function"===typeof a&&(a=[a]);for(e=0;e<a.length;e+=1)c.augment(b.prototype,a[e].prototype,!1)}};c.namespace=function(b,a){if(k){var c,g,d,f,h;c=b.split(".");g=c[c.length-1];d=k;for(h=0;h<c.length-1;h+=1)f=c[h],"undefined"===typeof d[f]&&(d[f]={}),d=d[f];d[g]=a}};"undefined"!==typeof define?define([],function(){return c}):k?k.Class=c:module.exports=c})("undefined"!==typeof define||"undefined"===typeof window?null:window);