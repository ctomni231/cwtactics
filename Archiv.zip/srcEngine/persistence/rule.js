model.event_on("prepare_game",function( dom ){
  model.rule_map.resetValues();
});

//model.event_on("load_game",function( dom ){});

//model.event_on("save_game",function( dom ){});