controller.screenStateMachine.structure.RULE_EDIT = Object.create(controller.stateParent);

controller.screenStateMachine.structure.RULE_EDIT.section = "cwt_ruleEditScreen";

controller.screenStateMachine.structure.RULE_EDIT.enterState = function(){
};