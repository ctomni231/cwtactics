controller.registerMenuRenderer("team_transferMoney",
function( content, entry, index ){
  
  entry.innerHTML = content+"$"; 
});