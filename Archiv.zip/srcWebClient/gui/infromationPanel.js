controller.updateComplexTileInformation = function(  ){
  
  
}