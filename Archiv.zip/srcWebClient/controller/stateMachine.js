controller.screenStateMachine = util.stateMachine({},{ noHistory:true });

controller.screenStateMachine.data = {};