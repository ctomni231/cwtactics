controller.imagePersistence_save = function(){

};